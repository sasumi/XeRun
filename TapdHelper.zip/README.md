# Tapd工单助手
1、该软件为免费使用软件，不对使用软件过程中出现任何问题负责，请自重。
2、若使用过程有任何建议或意见，请联系作者<a href="mailto:cnsasumi@outlook.com">cnsasumi@outlook.com</a>。

## 使用帮助

请在tapd工单列表中使用。